#include <iostream>
#include <map>
#include <queue>

using namespace std;

map < int, Konto > klienci;

class Transakcje{
private:
    execute(Transakcja transakcja){

    }
};

class Przelew :: Transakcje{
private:
    execute(Transakcja transakcja){
        transakcja.kto.stan-=transakcja.ile;
        transakcja.doKogo.stan+=transakcja.ile;
    }
};

class Konto{
public:
    int id;
    int numer;
    float stan;
};

class KolejkaTransakcji{
private:
    Klasa Instance;
    Klasa(){
        kolejkaTransakcji= new queue < Przelew > ;
    }
    queue < Przelew > kolejkaTransakcji;
public:
    KolejkaTransakcji getInstance(){
        if(Instance==NULL){
            Instance = new KolejkaTransakcji;
        }
        return Instance;
    }

};



class Transakcja{
public:
    Transakcja(){
        licznikWywolan=0;
    }
    Konto * kto;
    Konto * doKogo;
    float ile;
    int licznikWywolan;
    bool czyMozliwa(){
        if(kto.stan>=ile&&licznikWywolan<2){
            return true;
        }
        else{
            licznikWywolan++;
            return false;
        }
    }
};

void getKonta(string sciezka){

}

void getTransakcje(string sciezka){

}

void obslugujTransakcje(){
    queue kolejka =
    while( KolejkaTransakcji.front()!=NULL && kolejkaTransakcji.front().czyMozliwa() ){

        kolejkaTransakcji.front().execute();
    }
}

int main()
{
    obslugujTransakcje();

    return 0;
}

























