#include <iostream>
#include <map>
#include <stdio.h>
#include <stdlib.h>

using namespace std;


map <string, int> m;

int dni(string month){
    for(int i=0; i<month.length(); i++){
        month[i]=tolower(month[i]);
    }
    return m[month];
}

int main()
{
    m["styczen"]=31;
    m["sty"]=31;
    m["luty"]=28;
    m["lut"]=28;
    m["marzec"]=31;
    m["mar"]=31;
    m["kwiecien"]=30;
    m["kwi"]=30;
    m["maj"]=31;
    m["maj"]=31;
    m["czerwiec"]=30;
    m["cze"]=30;
    m["lipiec"]=31;
    m["lip"]=31;
    m["sierpien"]=31;
    m["sie"]=31;
    m["wrzesien"]=30;
    m["wrz"]=30;
    m["pazdziernik"]=31;
    m["paz"]=31;
    m["listopad"]=30;
    m["lis"]=30;
    m["grudzien"]=31;
    m["gru"]=31;

    string month;
    cin>>month;
    cout<<dni(month)<<endl;
    return 0;
}

