#include <iostream>
#include <fstream>
#include <vector>
#include "currency.h"
#include "country.h"
#include "item.h"
#include "customer.h"
#include "order.h"

using namespace std;

void getOrders(string fileName){
    fstream zamowienia(filename, ios::in);
    int number_of_lines = 0;
    string line;
    while (getline(zamowienia, line)){
        number_of_lines++;
    }
    Order * tab = new Order [number_of_lines];
    for(int i=0; i<number_of_lines; i++){
        zamowienia>>tab[i].customer.surname;
        zamowienia>>tab[i].customer.name;
        zamowienia>>tab[i].id;
        zamowienia>>tab[i].quantity;
        zamowienia>>tab[i].item.name;
        zamowienia>>tab[i].item.price;
        tab[i].total=tab[i].item.price*tab[i].quantity;
        tab[i].customer.country.currency.przelicz();
    }
}

void payForOrder(Order order){
    for(int i=0; i<order.items.size(); i++){
        order.items[i].price+=order.items[i].price*order.customer.country.tax;
        order.total+=order.items[i];
    }
}

int main()
{
    Country Polska;
    Polska.currency.currency=1;
    Polska.init="PL";
    Polska.name="Polska";
    Polska.tax=0.2;

    Country WielkaBrytania;
    WielkaBrytania.currency.currency=6;
    WielkaBrytania.init="EN";
    WielkaBrytania.name="Wielka Brytania";
    WielkaBrytania.tax=0.4;

    Currency PLN;
    PLN.currency=1;
    PLN.symbol="PLN";

    Currency GBP;
    GBP.currency=6;
    GBP.symbol="GBP";

    Item Stolik;
    Item Szafa;
    Item Lustro;
    Stolik.name="Stolik";
    Szafa.name="Szafa";
    Lustro.name="Lustro";

    Customer Tokar;
    Tokar.country=Polska;
    Tokar.name="Marcin";
    Tokar.surname="Tokar";

    Customer Omiotek;
    Omiotek.country=Polska;
    Omiotek.name="Piotr";
    Omiotek.surname="Omiotek";

    Customer Smith;
    Smith.country=WielkaBrytania;
    Smith.name="John";
    Smith.surname="Smith";

    getOrders(zamowienia.txt);

    return 0;
}































