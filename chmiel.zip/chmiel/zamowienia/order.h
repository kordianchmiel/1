#ifndef ORDER_H
#define ORDER_H

#include <vector>
#include <iostream>

using namespace std;

class Order
{
public:
    Order();
    int id;
    int quantity;
    Customer customer;
    Item item;
    float total=quantity*item.price;
};

#endif // ORDER_H
