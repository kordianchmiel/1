#ifndef COUNTRY_H
#define COUNTRY_H

#include <iostream>

using namespace std;

class Country
{
public:
    Country();
    string name;
    string init;
    float tax;
    Currency currency;
    getMoneyRules(Currency currency, float tax);
};

#endif // COUNTRY_H
