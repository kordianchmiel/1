#include "country.h"

Country::Country()
{
}

Country::getMoneyRules(Currency currency, float tax)
{
    this->currency=currency;
    this->tax=tax;
}
