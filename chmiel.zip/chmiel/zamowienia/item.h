#ifndef ITEM_H
#define ITEM_H

#include <iostream>

using namespace std;

class Item
{
public:
    Item();
    string name;
    float price;
};

#endif // ITEM_H
