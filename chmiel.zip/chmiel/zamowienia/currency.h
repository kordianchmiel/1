#ifndef CURRENCY_H
#define CURRENCY_H

#include <iostream>

using namespace std;

class Currency
{
public:
    Currency();
    string symbol;
    float currency;

    void przelicz(float total);
};

#endif // CURRENCY_H
