#include "currency.h"

Currency::Currency()
{

}

void Currency::przelicz(float total)
{
    total*=currency*1.05;
}
