#include <iostream>
#include <stack>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    stack<string> v;

    fstream plik1("plik1.txt", ios::in);
    fstream plik2("plik2.txt", ios::in);
    fstream plik3("plik3.txt", ios::out);

    while(!plik1.eof()){
        string a;
        getline(plik1,a);
        v.push(a);
    }

    while(!plik2.eof()){
        string b;
        getline(plik2,b);
        v.push(b);
    }

    for(unsigned int i=0; i<v.size(); i++){
        plik3<<v.top()<<endl;
        v.pop();
    }
    return 0;
}

