#include "Order.h"
#include <iostream>
using namespace std;

Order::Order( Country &country, int orderNumber ) : _payment(country), _country(country) {
    this->_orderNumber = orderNumber;
    cout << "Creating order # " << this->_orderNumber << endl;
}
Order::~Order() {
   vector<OrderSubGroup*>::iterator it;
   for ( it = this->_subGroups.begin(); it != this->_subGroups.end(); it++ )
       delete (*it);
}
bool Order::isOrderNumberEquals( int orderNumber ) {
    return this->_orderNumber == orderNumber;
}
void Order::addItemsSet( ItemsSet* itemsSet ) {
    vector<OrderSubGroup*>::iterator it;
    for ( it = this->_subGroups.begin(); it != this->_subGroups.end(); it++ )
        if ( ... ) {
            ...;
            cout << "Added itemSet " << itemsSet->toString() << endl;
            return;
        }
    /* nie znaleźliśmy tego typu - dodajemy na koniec */
    OrderSubGroup * orderSubGroup = new OrderSubGroup( itemsSet->getItemPattern() );
    ...;
    cout << "Added itemSet " << itemsSet->toString() << endl;
    ...;
}
float Order::calculateTotalWithTax() {
    // wyliczamy sumy poszczególnych grup
    float total = 0.0;    
    vector<OrderSubGroup*>::iterator it;
    for ( it = this->_subGroups.begin(); it != this->_subGroups.end(); it++ )
        total += ...;
    
    float tax = ...;
 
    return total + tax;
}
bool Order::pay( float amount ) {
    if (...) {
        cout << "Order # " << this->_orderNumber << " already paid" << endl;
        return false;
    }

    cout << "About to pay for order # " << this->_orderNumber << endl; 
    return ...;
}
bool Order::isPaid() {
    return this->_payment.isPaid();
}
