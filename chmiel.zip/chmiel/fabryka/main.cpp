#include <iostream>
#include <list>
using namespace std;
/*
W hotelu każdy pracownik ma dostęp tylko do określonych pomieszczeń w budynku.
Gość ma dostęp tylko do swojego pokoju.
Napisz program, który będzie tworzył Pracowników i automatycznie przydzielał im przysługujące im dostępy do pomieszczeń. Dostępy te powinny być reprezentowane jako zbiór numerów pomieszczeń w obiekcie Pracownika.
Program powinien wyświetlić numery pokojów, do których mają dostęp poszczególni pracownicy powyższych trzech typów.
*/

class Pracownik{
public:
    string typ;
    list <list> dostep;
    void wysw(){
        cout<<typ<<": ";
        list <list> wysw=dostep;
        while(wysw.size()>0){
            cout<<wysw.front()<<" ";
            wysw.pop_front();
        }
    }
};

class Fabryka{
public:
    Pracownik stworz();
};

class Fadmin::Fabryka{
public:
    Pracownik stworz(){
        Pracownik p = new Pracownik;
        p.typ="admin";
        for(int i=1; i<=40; i++){
            if(i!=20){                  //Administrator ma dostęp do wszystkich pokojów prócz pokoju szefa.
                p.dostep.push_front(i);
            }
        }
        return p;
    }
};

class Fszef::Fabryka{
public:
    Pracownik stworz(){
        Pracownik p = new Pracownik;
        p.typ="szef";
        for(int i=1; i<=40; i++){
            if(i==20||i==2||i==40||i==1){                  //Szef ma dostęp do swojego pokoju (nr 20), do magazynu (nr 2), do dachu (nr 40) i piwnicy (nr 1).
                p.dostep.push_front(i);
            }
        }
        return p;
    }
};

class Frecep::Fabryka{
public:
    Pracownik stworz(){
        Pracownik p = new Pracownik;
        p.typ="recep";
        for(int i=1; i<=40; i++){
            if(i!=20&&i!=40&&i!=1&&i!=3&&i!=4){                  //Recepcjonista ma dostęp do pokojów hotelowych (pozostałe numery ze zbioru od 1 do 40), do magazynu (2) i do sali konferencyjnej (11).
                p.dostep.push_front(i);
            }
        }
        return p;
    }
};

class Fsprz::Fabryka{
public:
    Pracownik stworz(){
        Pracownik p = new Pracownik;
        p.typ="sprz";
        for(int i=3; i<=40; i++){
            if(i!=20&&i!=40){                  //Sprzątaczka ma dostęp do pokoju dla sprzątaczek (3), do pokojów hotelowych, do sali konferencyjnej (11) i do pralni (4).
                p.dostep.push_front(i);
            }
        }
        return p;
    }
};

class Fgosc::Fabryka{
public:
    int pok;
    Fgosc(int pok){
        pok=pok;
    }
    Pracownik stworz(){
        Pracownik p = new Pracownik;
        p.typ="gosc";
        p.dostep.push_front(pok);

        return p;
    }
};

int main()
{
    return 0;
}

