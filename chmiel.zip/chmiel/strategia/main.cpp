#include <iostream>
using namespace std;
/*
Stwórz program do prostych rozliczeń podatkowych:
a. można rozliczać się jako osoba prawna lub fizyczna, podatek od osób prawnych wynosi 20%, od fizycznych 15% do ustalonego progu dochodu 100tys. na osobę oraz 30% dla kwoty powyżej tego progu,
b. osoba fizyczna może rozliczać się samemu lub z małżonkiem.
c. małżeństwo może odliczyć 500 zł na każde dziecko jako koszt uzyskania przychodu
d. zarówno osoba fizyczna jak i prawna może odliczyć czynsz swojego lokalu (mieszkania/siedziby) jako koszt uzyskania przychodu.
e. osoba fizyczna może odliczyć maksymalnie 10tys. jako koszty uzyskania przychodu, przysługują one również współmałżonkowi, co daje w sumie 20tys. Osoba prawna może odliczyć maksymalnie 15 tys. zł jako koszt uzyskania przychodu.
Napisz program, który dla podanych przychodów i parametrów niezbędnych do obliczenia kosztów uzyskania przychodu wyświetli wynik rozliczenia dla każdego z typów podatników.
*/
class Podatnik{
public:
    int przychod;
    int dochod;
    int prog=100000;
    int koszty=0;
    int czynsz;
    virtual float rozlicz()=0;
};

class Fizyczna::Podatnik{
public:
    float rozlicz(){
        koszty+=czynsz;
        if(koszty<=10000){
            dochod=przychod-koszty
        }
        else{
            dochod-=10000;
        }
        if(dochod<=prog){
            return 0.15*dochod;
        }
        else{
            return 0.3*dochod;
        }
    }
};

class Malzenstwo::Podatnik{
public:
    int dzieci;
    float rozlicz(){
        koszty+=czynsz;
        koszty+=500*dzieci;
    }

};

class Prawna::Podatnik{
public:

};

int main()
{

    return 0;
}

