#include <iostream>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

int main()
{
    vector<string> v;

    fstream plik1("plik1.txt", ios::in);
    fstream plik2("plik2.txt", ios::in);
    fstream plik3("plik3.txt", ios::out);
    while(!plik1.eof()){
        string a;
        getline(plik1,a);
        cout<<a<<endl;
        v.push_back(a);
    }
    while(!plik2.eof()){
        string a;
        getline(plik2,a);
        cout<<a<<endl;
        v.push_back(a);
    }



    int roz=v.size();
    for(int i=0; i<roz; i++){
        plik3<<v.back()<<endl;
        cout<<v.back()<<endl;
        v.pop_back();
    }
    plik3.close();
    return 0;
}

