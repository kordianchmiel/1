#include <iostream>
#include <sstream>
#include <cstring>
#include <math.h>
#include <stack>
#include <queue>
using namespace std;

bool isNumber(string a){
    if(a.compare("+")!=0&&a.compare("~")!=0&&a.compare("*")!=0&&
       a.compare("d")!=0&&a.compare("m")!=0&&a.compare("^")!=0&&
       a.compare("(")!=0&&a.compare("[")!=0&&a.compare("{")!=0&&
       a.compare(")")!=0&&a.compare("]")!=0&&a.compare("}")!=0){
        return 1;
    }
    else{
        return 0;
    }
}

bool isRightBracket(string a){
    if(a.compare(")")==0||a.compare("]")==0||a.compare("}")==0){
        return 1;
    }
    else{
        return 0;
    }
}

bool isLeftBracket(string a){
    if(a.compare("(")==0||a.compare("[")==0||a.compare("{")==0){
        return 1;
    }
    else{
        return 0;
    }
}

bool isBracket(string a){
    if(a.compare(")")==0||a.compare("]")==0||a.compare("}")==0||
       a.compare("(")==0||a.compare("[")==0||a.compare("{")==0){
        return 1;
    }
    else{
        return 0;
    }
}

bool isOperator(string a){
    if(a.compare("+")==0||a.compare("~")==0||a.compare("*")==0||
       a.compare("d")==0||a.compare("m")==0||a.compare("^")==0){
        return 1;
    }
    else{
        return 0;
    }
}

bool lewostronnieLaczny(string a){
    if(a.compare("+")==0||a.compare("~")==0||a.compare("*")==0||a.compare("d")==0||a.compare("m")==0){
        return true; // 1 dla lewostronnie lacznych;
    }
    else{
        return false; // 0 dla prawostronnie lacznych;
    }
}

bool prawostronnieLaczny(string a){
    if(a.compare("^")==0){
        return true; // 1 dla lewostronnie lacznych;
    }
    else{
        return false; // 0 dla prawostronnie lacznych;
    }
}

int Priority(string a){
    /*if(a.compare("(")==0||a.compare("[")==0||a.compare("{")==0){
                return 0;
    }*/
    if(a.compare("+")==0||a.compare("~")==0/*||a.compare(")")==0||a.compare("]")==0||a.compare("}")==0*/){
                return 2;
    }
    else if(a.compare("*")==0||a.compare("d")==0||a.compare("m")==0){
                return 3;
    }
    else /*if(a.compare("^")==0)*/{
                return 4;
    }
}

//class Element_stosu{
//public:
//    Element_stosu *poprzednik;       // Wskaznik na poprzedni element stosu
//    string wartosc;          // Wartość przechowywana w danym elemencie stosu
//};

//class stack{
//public:
//    int licznik=0;
//    Element_stosu *Top = NULL;       //Wierzchołek stosu
//    bool empty(){
//        return licznik==0;
//    }
//    void push(string Wartosc){    //dodanie elementu
//            Element_stosu * nowy = new Element_stosu;
//            nowy->wartosc = Wartosc;
//            nowy->poprzednik = Top;
//            Top = nowy;
//            licznik++;
//    }
//    void pop(){            //ściągnięcie elementu
//            if(!this->empty()){
//                Element_stosu * pomocnik = Top;
//                Top = Top->poprzednik;
//                delete pomocnik; //usuń ściągnięty wierzchołek
//                licznik--;
//        }
//    }

//    string top(){
//        if(!empty()){
//            return Top->wartosc;
//        }
//        else{
//            return NULL;
//        }
//    }
//};

//class Element_kolejki{
//public:
//    string wartosc;
//    Element_kolejki *poprzednik;
//    Element_kolejki *nastepnik;
//};

//class queue{
//public:
//    int licznik=0;
//    Element_kolejki *koniec = NULL;       //koniec kolejki
//    Element_kolejki *poczatek = NULL;       //początek kolejki
//    bool empty(){
//        return licznik==0;
//    }
//    void push(string Wartosc){    //dodanie elementu
//        if(licznik==0){
//            Element_kolejki * nowy = new Element_kolejki;
//            nowy->wartosc = Wartosc;
//            nowy->poprzednik = NULL;
//            nowy->nastepnik = NULL;
//            koniec = nowy;
//            poczatek = nowy;
//            licznik++;
//        }
//        else{
//            Element_kolejki * nowy = new Element_kolejki;
//            nowy->wartosc = Wartosc;
//            nowy->poprzednik = koniec;
//            nowy->nastepnik = NULL;
//            nowy->poprzednik->nastepnik = nowy;
//            koniec = nowy;
//            licznik++;
//        }
//    }
//    void pop(){            //ściągnięcie elementu
//            if(!empty()){
//                Element_kolejki * pomocnik = poczatek;
//                poczatek = poczatek->nastepnik;
//                delete pomocnik; //usuń ściągnięty wierzchołek
//                licznik--;
//        }
//    }

//    string top(){
//        if(!empty()){
//            return poczatek->wartosc;
//        }
//    }
//};

int main()
{
    int n;
    cin >> n;

    string * wejscie = new string [n];

    for(int i=0; i<n; i++){
        cin>>wejscie[i];
    }

    stack <string> stos;
    queue <string> wyjscie;
    int licz_nawias=0;

    for(int i=0; i<n; i++){
            if(wejscie[i].compare("}")==0||wejscie[i].compare("]")==0||wejscie[i].compare(")")==0){
                if(stos.empty()==1){
                    cout<<"bledne nawiasy";
                    return 0;
                }
                else{
                    if(stos.top().compare("{")==0&&wejscie[i].compare("}")==0){
                        stos.pop();
                    }
                    else if(stos.top().compare("[")==0&&wejscie[i].compare("]")==0){
                        stos.pop();
                    }
                    else if(stos.top().compare("(")==0&&wejscie[i].compare(")")==0){
                        stos.pop();
                    }
                }
            }
            else if(wejscie[i].compare("{")==0||wejscie[i].compare("[")==0||wejscie[i].compare("(")==0){
                stos.push(wejscie[i]);
                licz_nawias+=2;
            }
        }
        if(stos.empty()==0){
            cout<<"bledne nawiasy";
            return 0;
        }

    string * przekonwertowane = new string [n-licz_nawias];

    for(int m=0; m<n-1; m++){
        if((wejscie[m].compare("{")==0&&wejscie[m+1].compare("}")==0)||
           (wejscie[m].compare("[")==0&&wejscie[m+1].compare("]")==0)||
           (wejscie[m].compare("(")==0&&wejscie[m+1].compare(")")==0)){
               cout<<"bledna skladnia";
               return 0;
        }
    }

    for(int m=0; m<n-1; m++){
        if( (isOperator(wejscie[m])&&isOperator(wejscie[m+1]))||
            (isLeftBracket(wejscie[m])&&isOperator(wejscie[m+1]))||
            (isOperator(wejscie[m])&&isRightBracket(wejscie[m+1])) ){
            cout<<"bledna skladnia";
            return 0;
        }
        if(isNumber(wejscie[m])&&isNumber(wejscie[m+1])){
                cout<<"bledna skladnia";
                return 0;
        }
        if(isRightBracket(wejscie[m])&&isNumber(wejscie[m+1])){
                cout<<"bledna skladnia";
                return 0;
        }

        if( isRightBracket( wejscie[m] ) && isLeftBracket( wejscie[m+1] ) ){
                cout<<"bledna skladnia";
                return 0;
        }

        if( isNumber (wejscie[m]) && isLeftBracket(wejscie[m+1]) ){
                cout<<"bledna skladnia";
                return 0;
        }
    }
    if( isOperator( wejscie[0] ) || isRightBracket( wejscie[0] ) ||
        isOperator( wejscie[n-1] ) || isLeftBracket( wejscie[n-1] ) ){
           cout<<"bledna skladnia";
           return 0;
    }

    for(int m=0; m<n; m++){
        if( isNumber(wejscie[m]) ){
               wyjscie.push(wejscie[m]); // Jeśli symbol jest liczbą dodaj go do wyjscia.
        }
        if( isLeftBracket(wejscie[m]) ){
            stos.push(wejscie[m]); // Jeżeli symbol jest lewym nawiasem to włóż go na stos
        }
        if( isRightBracket(wejscie[m]) ){
            if(!stos.empty()){
                while( !isLeftBracket(stos.top()) ){
                    wyjscie.push(stos.top()); // Jeżeli symbol jest prawym nawiasem to zdejmuj operatory ze stosu
                    stos.pop();               // i dokładaj je do wyjscia, dopóki symbol na górze stosu
                                              // nie jest lewym nawiasem, kiedy dojdziesz do tego miejsca
                                              // zdejmij lewy nawias ze stosu bez dokładania go do wyjścia.
                }
                stos.pop(); //usuwa nawias otwierający ze stosu
            }
        }

        if(isOperator(wejscie[m])){
            while(!stos.empty()&&isOperator(stos.top())&&
                  ((lewostronnieLaczny(wejscie[m])&&Priority(wejscie[m])<=Priority(stos.top()))||
                   (prawostronnieLaczny(wejscie[m])&&Priority(wejscie[m])<Priority(stos.top())))){
                wyjscie.push(stos.top());
                stos.pop();
            }
            stos.push(wejscie[m]);
        }
    }
    /*
    Jeśli symbol jest operatorem, o1, wtedy:
    1) dopóki na górze stosu znajduje się operator, o2 taki, że:
    o1 jest lewostronnie łączny i jego kolejność wykonywania jest mniejsza lub równa kolejności wyk. o2,
    lub
    o1 jest prawostronnie łączny i jego kolejność wykonywania jest mniejsza od o2,
    zdejmij o2 ze stosu i dołóż go do wyjścia i wykonaj jeszcze raz 1)
    2) włóż o1 na stos */


    while(!stos.empty()){       //Jeśli nie ma więcej symboli do przeczytania, zdejmuj wszystkie symbole ze stosu
        wyjscie.push(stos.top());   //(jeśli jakieś są) i dodawaj je do wyjścia.
        stos.pop();
    }

    int m=0;

    while(!wyjscie.empty()){
        przekonwertowane[m]=wyjscie.front();  //przepisz wyjscie na tablice wejscia do nastepnych funkcji programu
        wyjscie.pop();
        m++;
    }

    n-=licz_nawias;

//    for(int m=0; m<n; m++){
//        cout<<przekonwertowane[m];
//    }

    int a;
    int b;

    stringstream ss;

    for(int m=0; m<n; m++){
        if( isNumber(przekonwertowane[m]) ){
               stos.push(przekonwertowane[m]);
        }
        else{
            ss.clear();
            ss << stos.top();
            ss >> a;
            stos.pop();
            ss.clear();
            ss << stos.top();
            ss >> b;
            stos.pop();
            ss.clear();
            if(przekonwertowane[m].compare("+")==0){
                int c=b+a;
                string d;
                ss.clear();
                ss << c;
                ss >> d;
                stos.push(d);
            }
            else if(przekonwertowane[m].compare("~")==0){
                int e=b-a;
                string f;
                ss.clear();
                ss << e;
                ss >> f;
                stos.push(f);
            }
            else if(przekonwertowane[m].compare("*")==0){
                int g=b*a;
                string h;
                ss.clear();
                ss << g;
                ss >> h;
                stos.push(h);
            }
            else if(przekonwertowane[m].compare("d")==0){
                if(a<=0){
                    cout<<"bledne dzialanie";
                    return 0;
                }
                else{
                    int i=b/a;
                    string j;
                    ss.clear();
                    ss << i;
                    ss >> j;
                    stos.push(j);
                }
            }
            else if(przekonwertowane[m].compare("m")==0){
                if(a==0){
                    cout<<"bledne dzialanie";
                    return 0;
                }
                else{
                    int k=b%a;
                    string l;
                    ss.clear();
                    ss << k;
                    ss >> l;
                    stos.push(l);
                }
            }
            else if(przekonwertowane[m].compare("^")==0){
                if((a==0&&b==0)||a<0){
                    cout<<"bledne dzialanie";
                    return 0;
                }
                else{
                    int o=pow(b,a);
                    string p;
                    ss.clear();
                    ss << o;
                    ss >> p;
                    stos.push(p);
                }
            }
        }
    }

    cout<<stos.top()<<endl;

    return 0;
}
