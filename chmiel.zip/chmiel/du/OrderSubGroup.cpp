#include "OrderSubGroup.h"
#include <iostream>
using namespace std;

OrderSubGroup::OrderSubGroup( Item itemPattern ) : _itemPattern(itemPattern) {
    cout << "Creating subgroup for itempattern " << itemPattern.toString() << endl;
}
OrderSubGroup::~OrderSubGroup(){
    vector<ItemsSet*>::iterator it;
    for ( it = this->_itemSets.begin(); it != this->_itemSets.end(); it++ )
        delete (*it);
}

void OrderSubGroup::addItemsSet( ItemsSet* itemsSet ) {
    if ( itemsSet.getItemPattern() == this._itemPattern )//podgrupa pasuje
        this.addItemsSet(itemsSet);
    else
        cout << "Can't add itemsSet. Item = " << itemsSet->getItemPattern().toString() <<
                " pattern = " << this->_itemPattern.toString();
}
bool OrderSubGroup::isForSameItem( ItemsSet* itemsSet) {
    return this->_itemPattern == itemsSet->getItemPattern();
}
float OrderSubGroup::calculateSubTotalWithoutTax() {
    float total = 0.0;
    int quantity = 0;
    vector<ItemsSet*>::iterator it;
    for ( it = this->_itemSets.begin(); it != this->_itemSets.end(); it++ ) {
        total += this.calculateSubTotalWithoutTax();
        quantity += 1;
    }
    float discount = this->calculateDiscountForQuantity( quantity, total );

    return total - discount;
}
float OrderSubGroup::calculateDiscountForQuantity( int quantity, float amount ) {
    // jeszcze nie przerobiliśmy strategii
    if (this->_itemPattern == Item("Lustro") ){
        if ( quantity > 10 )
            return 0.08;
    }

    return 0.0;
}

